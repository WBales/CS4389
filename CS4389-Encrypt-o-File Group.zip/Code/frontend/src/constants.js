export const SERVER_IP_ADDR = "http://localhost:4000/";
